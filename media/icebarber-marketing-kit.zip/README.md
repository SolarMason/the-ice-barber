# The Ice Barber LLC — Marketing Kit

A complete print-ready marketing package designed around an **eco-conscious aesthetic**: cream paper, brand colors used sparingly as accents, generous whitespace. The result is roughly **70–85% less ink coverage** per piece than a flooded-color design, while the brand stays instantly recognizable.

Every PDF includes a QR code that decodes to **https://theicebarber.com** (verified across all 8 files).

## What's in the kit

| # | Piece | Size | Use |
|---|---|---|---|
| 01 | **Business Card** | 3.5″ × 2″ (front + back, with bleed) | Networking, event handouts |
| 02 | **Flyer** | 8.5″ × 11″ letter | Bulletin boards, mailers, handouts |
| 03 | **Door Hanger** | 4.25″ × 11″ with knob cutout | Residential canvassing |
| 04 | **Postcard** | 6″ × 4.25″ USPS-mailable | Direct mail, bulk send |
| 05 | **Rack Card** | 4″ × 9″ (front + back) | Hotel racks, info booths |
| 06 | **Tear-Off Flyer** | 8.5″ × 11″ with 10 wider phone-tab strips | Coffee shops, libraries, community boards |
| 07 | **Event Sales Sheet** | 8.5″ × 11″ professional B2B | Leave-behind for venues, planners, school admins |
| 08 | **Poster** | 11″ × 17″ tabloid | Schools, churches, fairs — high-visibility |

## Design philosophy: eco-conscious print

- **Cream paper background** (`#FAF6EC`) — evokes recycled/kraft stock, dramatically reduces ink coverage vs flooded color backgrounds.
- **Brand colors as accents only** — thin top stripe, color-dot section markers, outlined cards, accent underlines. Pink, orange, yellow and sky now appear as small pops, never as background floods.
- **Hairline rules and outlined shapes** instead of filled cards — preserves structure with a fraction of the ink.
- **Outlined pills** for flavor labels — same color identity, ~10% the ink of solid pills.
- **Leaf eco-mark + footer** on every piece: *"Family-Owned • Mindfully Printed on Recyclable Paper • NEPA"*
- **Generous whitespace** throughout — feels premium and intentional, especially on the tear-off where the strip went from 14 cramped tabs to **10 wider tabs** with bigger, more legible phone numbers.

The headline typography (*Cool Down Your Event.*, *Cool Off Your Crowd.*, *We're in Your Neighborhood.*) stays bold and confident — eco doesn't mean timid.

## Print specs

- **Paper recommendation:** uncoated or matte stock, 30–100% post-consumer recycled. Cream/natural shade pairs perfectly with the file backgrounds. Common options: Mohawk Loop, Domtar EarthChoice, Rolland Enviro.
- **Color profile:** RGB (most digital print shops convert to CMYK on press; the cream tone converts cleanly)
- **Bleed:** 0.125″ on cards/postcards/rack cards (already included in PDF page size)
- **Resolution:** Vector + 300 DPI logo embedded — scales cleanly to any size

## Where to print

- **Local NEPA print shop on recycled stock** — best for the eco message; ask for FSC-certified uncoated paper
- **GreenerPrinter, Conscious Minds Printing** — eco-specialty national shops
- **VistaPrint / GotPrint / 4Over** — fastest and cheapest; choose recycled stock options where available

When uploading, choose **"Print-ready PDF with bleed"** and the pre-set sizes match standard offerings.

## Brand colors

- Strawberry pink: `#EE407F`
- Lemonade yellow: `#FFD42D`
- Orange lemonade: `#F7931E`
- Sky cyan: `#29C3E5`
- Deep navy: `#022658`
- Beard blue: `#084E89`

Eco palette additions (system colors, not customer-facing brand):
- Cream paper: `#FAF6EC`
- Hairline rule: `#C9BFA8`
- Leaf eco-mark: `#5B7A3F`

## QR codes

Every QR decodes to **https://theicebarber.com** — verified by extracting and decoding every embedded QR image in all 8 final PDFs. No reprints needed when the site itself updates.

## Contact info embedded

- **Phone:** (570) 251-1996
- **Email:** theicebarber@gmail.com
- **Web:** theicebarber.com
- **Service area:** Lackawanna, Luzerne, Wyoming, Susquehanna and surrounding NEPA counties

---

*Designed as a matching brand system. The whole kit reads as a single voice — bold typography, restrained color, eco-conscious by default.*
